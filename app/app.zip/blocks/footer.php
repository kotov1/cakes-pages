<footer class="footer" style="top: -25px">

	<div class="container" style="padding-right: 0; padding-left: 0">
		<div class="row no-gutters">
			<div class="col-xl-12">

				<div class="footerContent">
					<div class="footerContent__LogoWrap">
						<div class="footerContent__Logo"></div>
					</div>
					<div class="footerContent__MenuWrap">
						<ul class="footerContent__Menu">
							<li class="footerContent__Menu_Item"><a href="#" class="footerContent__Menu_ItemHref">Главная</a></li>
							<li class="footerContent__Menu_Item"><a href="#" class="footerContent__Menu_ItemHref">О нас</a></li>
							<li class="footerContent__Menu_Item"><a href="#" class="footerContent__Menu_ItemHref">Доставка и оплата</a></li>
							<li class="footerContent__Menu_Item"><a href="#" class="footerContent__Menu_ItemHref">Новости и акции</a></li>
							<li class="footerContent__Menu_Item"><a href="#" class="footerContent__Menu_ItemHref">Контакты</a></li>
						</ul>
					</div>
					<div class="footerContent__TelWrap">
						<p class="footerContent__TelNumber">+7 (123) 456-78-90</p>
						<a href="#" class="footerContent__TelHref">Заказать звонок</a>
						<a href="#" class="footerContent__TelEmail">info@onmycake.ru</a>
						<div class="footerContent__TelWrapLeft"></div>
						<div class="footerContent__TelWrapright"></div>			
					</div>
					<div class="footerContent__SocWrap">
						<div class="footerContent__SocCart">
							<div class="footerContent__SocCart_1"></div>
							<div class="footerContent__SocCart_2"></div>

						</div>
						<div class="footerContent__SocSet">
							<a href="#" class="footerContent__SocSet_size footerContent__SocSet_Margin"><i class="fa fa-facebook" aria-hidden="true"></i></a>
							<a href="#" class="link_FB footerContent__SocSet_size footerContent__SocSet_Margin"><i class="fa fa-vk" aria-hidden="true"></i></a>
							<a href="#" class="link_OK footerContent__SocSet_size footerContent__SocSet_Margin"><i class="fa fa-instagram" aria-hidden="true"></i></a>
							<a href="#" class="link_Inst footerContent__SocSet_size"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
						</div>
					</div>
					<div class="footerContent__CopyrWrap">
						<p class="footerContent__Copyr">Создание сайта: <a href="#" class="footerContent__CopyrHref">Океан Digital</a></p>					
						<!-- 					<p class="footerContent__Copyr">© 2014 — 2017, Oh, My Cake. Все права защищены</p> -->
					</div>
				</div>

			</div>
		</div>
	</div>

	<div class="footerMain">
	</div>	
</footer>